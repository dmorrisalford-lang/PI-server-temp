import time
import board
import adafruit_dht

# DHT11 on GPIO4 (pin 7)
dht = adafruit_dht.DHT11(board.D4)

while True:
    try:
        temp_c = dht.temperature
        hum = dht.humidity
        print(f"Temp: {temp_c} C  Humidity: {hum} %")
    except Exception as e:
        print("Read error:", e)
    time.sleep(3)

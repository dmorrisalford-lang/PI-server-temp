#!/usr/bin/env python3
import time
import csv
import os
import board
import adafruit_dht
from flask import Flask, Response, jsonify

# DHT11 on GPIO4, bit-banged mode
dht = adafruit_dht.DHT11(board.D4, use_pulseio=False)

app = Flask(__name__)

LOG_FILE = "dht11_log.csv"

HTML = """\
<!DOCTYPE html>
<html>
<head>
  <title>Server Case Environment</title>
  <meta http-equiv="refresh" content="5">
  <style>
    body {{ font-family: Arial, sans-serif; background: #111; color: #eee; text-align: center; }}
    .card {{ display: inline-block; padding: 20px; margin-top: 40px;
            border: 1px solid #444; border-radius: 8px; background: #222; }}
    h1 {{ margin-bottom: 10px; }}
    p {{ font-size: 1.2rem; }}
  </style>
</head>
<body>
  <div class="card">
    <h1>Server Case Sensor</h1>
    <p>Temperature: {temp}&deg;C</p>
    <p>Humidity: {hum}%</p>
    <p>Last update: {ts}</p>
  </div>
</body>
</html>
"""

def read_dht():
    try:
        temp_c = dht.temperature
        hum = dht.humidity
        if temp_c is None or hum is None:
            return None, None
        return round(temp_c, 1), round(hum, 1)
    except Exception:
        return None, None

def log_reading(timestamp, temp, hum):
    """Append a line to CSV log; create file with header if needed."""
    new_file = not os.path.exists(LOG_FILE)
    with open(LOG_FILE, "a", newline="") as f:
        writer = csv.writer(f)
        if new_file:
            writer.writerow(["timestamp", "temperature_c", "humidity_percent"])
        writer.writerow([timestamp, temp, hum])

@app.route("/")
def index():
    temp, hum = read_dht()
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    if temp is not None and hum is not None:
        log_reading(ts, temp, hum)
        t_display = temp
        h_display = hum
    else:
        t_display = "ERR"
        h_display = "ERR"
    page = HTML.format(temp=t_display, hum=h_display, ts=ts)
    return Response(page, mimetype="text/html")

@app.route("/json")
def json_metrics():
    temp, hum = read_dht()
    ts = int(time.time())
    if temp is None or hum is None:
        return jsonify({"ok": False, "timestamp": ts, "error": "read_failed"}), 503
    return jsonify(
        {
            "ok": True,
            "timestamp": ts,
            "temperature_c": temp,
            "humidity_percent": hum,
        }
    )

if __name__ == "__main__":
    # Bind to all interfaces, port 8080
    app.run(host="0.0.0.0", port=8080, debug=False)
